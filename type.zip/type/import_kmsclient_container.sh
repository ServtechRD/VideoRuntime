#!/bin/bash

BUILD_DATE='20241025'
IMAGE_NAME='servtech/musesai_cloud_kmsclient:v'${BUILD_DATE}
CONTAINER_NAME='musesai_cloud_kmsclient_v'${BUILD_DATE}

OFF='\033[0m'
YELLOW='\033[0;33m'

# install dongle driver ======
echo -e "install dongle driver "
sudo dpkg -i *.deb


# install usb sync
echo -e "install usb sync"
sed -i "s/container_name/$CONTAINER_NAME/" ./docker-usb-sync.py
sudo cp ./docker-usb-sync.py /usr/bin/
sudo chmod 777 /usr/bin/docker-usb-sync.py


# install usb trigger
echo -e "install usb trigger"
sudo cp ./90-hasp.rules /etc/udev/rules.d/
sudo service udev restart


# import container ============
if [[ "$(docker images -q ${IMAGE_NAME} 2> /dev/null)" == "" ]]; then
	echo -e "${YELLOW} > docker image does not exist, start to import image...${OFF}"
	docker load < musesai_cloud_kmsclient_v${BUILD_DATE}.tgz
	echo -e "${YELLOW} > import complete${OFF}"
else
	echo -e "${YELLOW} > docker image exists already${OFF}"
fi

# Get current path
CURRENT_PATH=$(pwd)
DATA_PATH=/aiplatform

echo -e "data path : $DATA_PATH"

if [ -d "$DATA_PATH" ]; then
   echo -e "$DATA_PATH already exist"
else
   echo -e "$DATA_PATH  not exist ,create it "
   mkdir -p $DATA_PATH
fi

EXT_DISK_MAP=""

if [ $# -ne 0 ]; then
   echo -e "Have Ext Disk Map :$*"
   for arg in "$@"; do
     EXT_DISK_MAP+=" -v $arg:$arg"
   done
   EXT_DISK_MAP+=" "
fi

echo "$EXT_DISK_MAP"

# create and start container
if [[ "$(docker inspect --format . ${CONTAINER_NAME} 2> /dev/null)" == "." ]]; then
	echo -e "${YELLOW} > container exists already${OFF}"
else
	echo -e "${YELLOW} > start to create container${OFF}"
	docker create -i --name ${CONTAINER_NAME} --pid=host --restart=unless-stopped -v $DATA_PATH:/aiplatform $EXT_DISK_MAP --log-driver json-file --log-opt max-size=10m --log-opt max-file=10 --privileged -v /dev/bus/usb ${IMAGE_NAME}
	echo -e "${YELLOW} > container created${OFF}"
fi


